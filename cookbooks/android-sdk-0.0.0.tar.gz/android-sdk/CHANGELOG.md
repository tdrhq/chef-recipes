# CHANGELOG for Android-SDK cookbook

## 0.1.0 (not release yet)

*Initial release* created for Travis CI needs (see travis-ci/travis-workeri#56)

## 0.0.1

*Dummy release* to learn how to use kitchen-community plugin

## 0.0.0

*First Draft*

* GH-1: example of closed issue / release item

