default[:rvm][:ruby][:implementation] = 'ree'
