default[:rvm][:ruby][:default] = true
