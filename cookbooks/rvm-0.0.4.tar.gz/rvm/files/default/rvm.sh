# this doesn't work for me!
# [[ -s "/usr/local/lib/rvm" ]] && . "/usr/local/lib/rvm"  # This loads RVM into a shell session.
source /usr/local/lib/rvm
