#!/bin/sh
exec /usr/local/rvm/bin/rvm gem $*
